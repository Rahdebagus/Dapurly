package com.project.dapurly.model

data class Resep2RowModel(
    var txtAyamGorengMen: String? = "",
    var txtYunita: String? = "",
    var txtFiveHundredTwelve: String? = ""
)
