package com.project.dapurly.model

data class ReviewRowModel(
  var txtJokoIdaman: String? = "",
  var txtLevelBronze: String? = "",
  var txtFive: String? = "",
  var txtTerimakasihre: String? = "",
)
