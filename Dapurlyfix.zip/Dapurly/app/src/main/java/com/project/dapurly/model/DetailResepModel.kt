package com.project.dapurly.model

data class DetailResepModel(
  var txtOrangCounter: String? = "",
  var txtRiceCooker: String? = ""

)
