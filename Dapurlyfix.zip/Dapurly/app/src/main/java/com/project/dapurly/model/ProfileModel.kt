package com.project.dapurly.model

class ProfileModel {
}