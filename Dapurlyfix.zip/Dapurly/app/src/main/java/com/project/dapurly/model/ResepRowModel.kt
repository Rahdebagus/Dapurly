package com.project.dapurly.model

data class ResepRowModel(
  var txtTanpaPresto: String? = "",
  var txt4912: String? = "",
  var txtRotiJalaMakL: String? = ""

)
